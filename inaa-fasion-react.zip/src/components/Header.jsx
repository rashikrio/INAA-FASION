import React from "react";
import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="bg-dark text-cream py-4 shadow-md flex justify-between items-center px-8">
      <h1 className="text-2xl font-bold tracking-wide">INAA FASION</h1>
      <nav className="space-x-6">
        <Link to="/" className="hover:text-roseGold">Home</Link>
        <Link to="/checkout" className="hover:text-roseGold">Checkout</Link>
      </nav>
    </header>
  );
}
