/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        roseGold: "#b76e79",
        cream: "#f9f4ef",
        dark: "#1f1f1f",
      },
    },
  },
  plugins: [],
}
