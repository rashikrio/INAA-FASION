import React from "react";

export default function Home() {
  return (
    <section className="p-10 text-center">
      <h2 className="text-4xl font-bold text-roseGold mb-6">
        Welcome to INAA FASION
      </h2>
      <p className="text-lg text-dark/80 max-w-2xl mx-auto">
        Explore our luxurious collection of maternity wear, kurtis, co-ord sets,
        and more — crafted for elegance and comfort.
      </p>
    </section>
  );
}
